self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2b83f92d70138883ac05133bc13b9fe0",
    "url": "./index.html"
  },
  {
    "revision": "1dee162d40bc4eb5cc22",
    "url": "./static/css/main.06546a2e.chunk.css"
  },
  {
    "revision": "05469181b847ddbc620a",
    "url": "./static/js/2.c63472e1.chunk.js"
  },
  {
    "revision": "b51e62edbcf7a9c4f4ad13f506021d3e",
    "url": "./static/js/2.c63472e1.chunk.js.LICENSE"
  },
  {
    "revision": "1dee162d40bc4eb5cc22",
    "url": "./static/js/main.fa1b18dd.chunk.js"
  },
  {
    "revision": "308804ed7b4d7003afb1",
    "url": "./static/js/runtime-main.502b070e.js"
  }
]);